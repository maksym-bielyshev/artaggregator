from django.apps import AppConfig


class TesturlappConfig(AppConfig):
    name = 'testurlapp'
