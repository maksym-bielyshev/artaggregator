from django.conf.urls import url
from testurlapp import views

urlpatterns = [
    url(r'^user/(\d+)/$', views.home, name='home'),
    #site.com/user/12
]