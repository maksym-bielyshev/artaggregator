from django.apps import AppConfig


class TeststaticappConfig(AppConfig):
    name = 'teststaticapp'
