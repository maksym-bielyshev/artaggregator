from django.db import models

# Create your models here.


class Project(models.Model):
    name = models.CharField(max_length=30, verbose_name='Проект')
    description = models.TextField(verbose_name='Описание')

    class Meta:
        verbose_name = 'Проект'
        verbose_name_plural = 'Проекты'

    def __str__(self):
        return self.name


class Work(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE)
    name = models.CharField(max_length=30, verbose_name='Название картины')
    picture = models.ImageField('Картина', upload_to='app/pictures', default='')
    short_description = models.CharField(max_length=30, verbose_name='Краткое описание')
    price = models.FloatField(default=0, verbose_name='Цена')

    class Meta:
        verbose_name = 'Работа'
        verbose_name_plural = 'Работы'
        ordering = ['name']

    def __str__(self):
        return self.name


class Order(models.Model):
    work = models.ForeignKey(Work, verbose_name='Картина')
    name = models.CharField(max_length=30, verbose_name='Имя')
    phone = models.CharField(max_length=30, verbose_name='Телефон')
    date = models.DateTimeField(auto_now_add=True, verbose_name='Дата')
