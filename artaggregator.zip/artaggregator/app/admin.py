from django.contrib import admin
from app.models import Project, Work, Order

# Register your models here.

admin.site.register(Project)
admin.site.register(Work)


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['work', 'name', 'phone', 'date']
