from django import forms
from app.models import Order
from app.models import Work


class OrderForm(forms.ModelForm):
    work = forms.ModelChoiceField(queryset=Work.objects.all(), widget=forms.HiddenInput)

    class Meta:
        model = Order
        fields = ('work', 'name', 'phone')
