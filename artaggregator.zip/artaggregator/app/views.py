from django.shortcuts import render, get_object_or_404
from app.models import Work

from app.forms import OrderForm

from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse

# Create your views here.


def home(request):
    works = Work.objects.all()
    return render(request, 'index.html', {'works': works})


def work_detail(request, work_id):
    work = get_object_or_404(Work, id=work_id)
    form = OrderForm(request.POST or None, initial={
        'work': work
    })

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('{}?sent=True'.format(reverse('work_detail', kwargs={'work_id': work.id})))

    return render(request, 'work_detail.html', {
        'work': work,
        'form': form,
        'sent': request.GET.get('sent', False)
    })
